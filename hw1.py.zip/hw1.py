
class Logic:
  def bitwiseXOR(self, num1,num2,num3):
    res = num1 ^ num2
    res = res ^ num3
    return res
  
# l = Logic()
# print(l.bitwiseXOR(8,13,31))
